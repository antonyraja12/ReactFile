import logo from './logo.svg';
import './App.css';
import EmployeeForm from './components/empForm';

function App() {
  return (
   <>
   <EmployeeForm />
   </>  );
}

export default App;
