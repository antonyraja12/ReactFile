import React, { useState } from 'react';
import FirstFormPage from './firstpage';
import SecondFormPage from './secondpage';
// import FirstFormPage from './FirstFormPa
// import SecondFormPage from './SecondFormPage';

const EmployeeForm = () => {
  const [page, setPage] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    bankName: '',
    accountNumber: '',
  });

  const [errors, setErrors] = useState({});

  const nextPage = () => {
    // Validate and proceed to the next page
    if (validateForm()) {
      setPage(page + 1);
    }
  };

  const previousPage = () => {
    setPage(page - 1);
  };

  const handleSubmit = () => {
    // Validate and submit the form
    if (validateForm()) {
      // Save data to local storage or perform other actions
      console.log('Form Data:', formData);
      alert('Form submitted successfully!');
    //   console.log(data);
    
    }
  };

  const validateForm = () => {
    const newErrors = {};
    // Add your validation logic here
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  return (
    <div>
      {page === 1 && (
        <FirstFormPage
          formData={formData}
          setFormData={setFormData}
          errors={errors}
          nextPage={nextPage}
        />
      )}
      {page === 2 && (
        <SecondFormPage
          formData={formData}
          setFormData={setFormData}
          errors={errors}
          previousPage={previousPage}
          handleSubmit={handleSubmit}
        />
      )}
    </div>
  );
};

export default EmployeeForm;
