import React from 'react';

const FirstFormPage = ({ formData, setFormData, errors, nextPage }) => {
  return (
    <div>
      <h2>Page 1: Basic Details</h2>
      <label>First Name:</label>
      <input
        type="text"
        value={formData.firstName}
        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
      />
      <p style={{ color: 'red' }}>{errors.firstName}</p>

      <label>Last Name:</label>
      <input
        type="text"
        value={formData.lastName}
        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
      />
      <p style={{ color: 'red' }}>{errors.lastName}</p>

      <button onClick={nextPage}>Next</button>
    </div>
  );
};

export default FirstFormPage;
