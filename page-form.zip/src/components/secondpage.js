import React from 'react';

const SecondFormPage = ({ formData, setFormData, errors, previousPage, handleSubmit }) => {
  return (
    <div>
      <h2>Page 2: Bank Details</h2>
      <label>Bank Name:</label>
      <input
        type="text"
        value={formData.bankName}
        onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
      />
      <p style={{ color: 'red' }}>{errors.bankName}</p>

      <label>Account Number:</label>
      <input
        type="text"
        value={formData.accountNumber}
        onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
      />
      <p style={{ color: 'red' }}>{errors.accountNumber}</p>

      <button onClick={previousPage}>Previous</button>
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
};

export default SecondFormPage;
