// import React, { useState } from 'react';
// import FirstFormPage from './firstpage';
// import SecondFormPage from './secondpage';
// // import FirstFormPage from './FirstFormPa
// // import SecondFormPage from './SecondFormPage';

// const EmployeeForm = () => {
//   const [page, setPage] = useState(1);
//   const [formData, setFormData] = useState({
//     firstName: '',
//     lastName: '',
//     bankName: '',
//     accountNumber: '',
//   });

//   const [errors, setErrors] = useState({});

//   const nextPage = () => {
//     // Validate and proceed to the next page
//     if (validateForm()) {
//       setPage(page + 1);
//     }
//   };

//   const previousPage = () => {
//     setPage(page - 1);
//   };

//   const handleSubmit = () => {
//     // Validate and submit the form
//     if (validateForm()) {
//       // Save data to local storage or perform other actions
//       console.log('Form Data:', formData);
//       alert('Form submitted successfully!');
//     //   console.log(data);
    
//     }
//   };

//   const validateForm = () => {
//     const newErrors = {};
//     // Add your validation logic here
//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };

//   return (
//     <div>
//       {page === 1 && (
//         <FirstFormPage
//           formData={formData}
//           setFormData={setFormData}
//           errors={errors}
//           nextPage={nextPage}
//         />
//       )}
//       {page === 2 && (
//         <SecondFormPage
//           formData={formData}
//           setFormData={setFormData}
//           errors={errors}
//           previousPage={previousPage}
//           handleSubmit={handleSubmit}
//         />
//       )}
//     </div>
//   );
// };

// export default EmployeeForm;

import React, { useState } from 'react';
import FirstFormPage from './firstpage';
import SecondFormPage from './secondpage';
import Stepper from 'react-stepper-horizontal';

const steps = [
  { title: 'Basic Details' },
  { title: 'Bank Details' },
];

const EmployeeForm = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    bankName: '',
    accountNumber: '',
  });

  const [errors, setErrors] = useState({});

  const handleNext = () => {
    if (validateForm()) {
      setActiveStep(activeStep + 1);
    }
  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  const handleSubmit = () => {
    if (validateForm()) {
      console.log('Form Data:', formData);
      alert('Form submitted successfully!');
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (formData.firstName.trim().length < 3) {
      newErrors.firstName = 'First Name must be at least 3 characters';
    }
  
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  return (
    <div>
      <h1>Employee Details</h1>

      <Stepper steps={steps} activeStep={activeStep} />

      {activeStep === 0 && (
        <FirstFormPage
          formData={formData}
          setFormData={setFormData}
          errors={errors}
          nextPage={handleNext}
        />
      )}

      {activeStep === 1 && (
        <SecondFormPage
          formData={formData}
          setFormData={setFormData}
          errors={errors}
          previousPage={handleBack}
          handleSubmit={handleSubmit}
        />
      )}

      <div>
        {/* <button disabled={activeStep === 0} onClick={handleBack}>
          Back
        </button>
        <button disabled={activeStep === 1} onClick={handleNext}>
          Next
        </button> */}
        {activeStep === 1 && (
          <button onClick={handleSubmit}>Submit</button>
        )}
      </div>
    </div>
  );
};

export default EmployeeForm;
